################## WORKING SPACE
mkdir workspace_overlay
cp ../../hw/prj/top_wrapper.xsa  ./workspace_overlay
cd workspace_overlay
source /opt/Xilinx/Vitis/2022.2/settings64.sh 

################## CREATE DT
xsct
hsi::open_hw_design top_wrapper.xsa
createdts -hw top_wrapper.xsa -zocl -platform-name kv260_hw_platform -git-branch xlnx_rel_v2022.2 -overlay -compile -out ./KV260_dt
exit
################## COMPILE DT
dtc -@ -O dtb -o ./kv260.dtbo ./KV260_dt/KV260_dt/kv260_hw_platform/psu_cortexa53_0/device_tree_domain/bsp/pl.dtsi

################## PREPARE REQUIRED FILES
echo '{ "shell_type" : "XRT_FLAT", "num_slots": "1" }' > shell.json

mkdir KV260_DPU
cp shell.json ./KV260_DPU
cp top_wrapper.bit ./KV260_DPU/kv260_dpu.bit.bin
cp kv260.dtbo ./KV260_DPU/kv260_dpu.dtbo
